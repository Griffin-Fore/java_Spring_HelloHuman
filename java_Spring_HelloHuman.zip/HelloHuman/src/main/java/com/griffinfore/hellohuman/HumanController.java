package com.griffinfore.hellohuman;

import java.util.ArrayList;
import java.util.StringJoiner;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

// "ctrl + shift + o" to load the imports
@RestController
public class HumanController {
	@RequestMapping("/")
//	the url is localhost:8080/?q=griffin&last_name=fore, where griffin is assigned to the first variable
	public String searchPage(@RequestParam(value = "q", required = false) String name,
			@RequestParam(value = "last_name", required = false ) String last_name,
			@RequestParam(value = "times", required = false) Integer times) {
		if(name == null && last_name == null && times == null) {
			return "Hello human";
		}
		else if(last_name == null && times == null) {
			System.out.println(name);
			return "Hello " + name;
		}
		else if(times == null) {
			System.out.println(name);
			System.out.println(last_name);
			return "Hello " + name + " " + last_name;
		}
		else {
			System.out.println(name);
			System.out.println(last_name);
			System.out.println(times);
			// How to repeat the input names a set amount of time
			ArrayList<String> repeatName = new ArrayList<String>();
			for(int i = 0; i < times; i++) {
				repeatName.add("Hello "+ name + " " + last_name);
			}
			StringJoiner joinStrings = new StringJoiner(" ");
			for(String greeting : repeatName) {
				joinStrings.add(greeting);
			}
			
			return joinStrings.toString();
		}
//		"?q=" to search
	}
// " " and "/" are different in this case because the body of / contains different information
}
